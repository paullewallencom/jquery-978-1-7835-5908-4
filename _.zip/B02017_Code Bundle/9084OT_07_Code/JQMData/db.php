<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "Civic_Center";

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>