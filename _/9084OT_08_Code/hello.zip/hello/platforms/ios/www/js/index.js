document.addEventListener("deviceready", onDeviceReady, false);

/* Function to display alert message*/
function showAlert() {
    navigator.notification.alert(
        'You are the winner!',  // message
        null,                   // callback
        'Game Over',            // title
        'Done'                  // buttonName
    );
    playBeep();
    vibrate();
}

/* Function to play a beep sound*/
function playBeep() {
    navigator.notification.beep(1);
}

/* Function to make the device vibrate*/
function vibrate() {
    navigator.notification.vibrate(2000);
}

/* Function to display a confirm dialog box*/
function showConfirm() {
    navigator.notification.confirm(
        'You are the winner!',  // message
        onConfirm,              // callback to invoke with index of button pressed
        'Game Over',            // title
        'Restart,Exit'          // buttonLabels
    );
}

/* The confirm dialog callback function*/
function onConfirm(buttonIndex) {
    var butttonText = '';
    if (buttonIndex == 1){
        butttonText = 'Restart';
    }
    else{
        butttonText = 'Exit'
    }
    alert('You selected the ' + butttonText + ' button.');
}

/* Function to display a prompt box*/
function showPrompt() {
    navigator.notification.prompt(
        'Please enter your name',   // message
        onPrompt,                   // callback to invoke
        'Registration',             // title
        ['Ok', 'Exit'],             // buttonLabels
        'Jane Doe'                  // defaultText
    );
}

/* The prompt dialog callback funtion*/
function onPrompt(results) {
    alert('You entered ' + results.input1);
}