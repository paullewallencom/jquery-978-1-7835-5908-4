#!/usr/bin/env bash
echo "$ rake build"
rake build